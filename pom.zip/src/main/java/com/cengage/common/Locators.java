package com.cengage.common;

public enum Locators 
{
    id, name, classname, css,cssSelector, xpath, linktext;
}