package com.cengage.b2c.orderrepository;

public enum userType {
	
	existing,
	create


}
