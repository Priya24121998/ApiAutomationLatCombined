package com.cengage.b2c.orderrepository;

public enum CreditCardTypeB2C {
	
	Visa,
    MasterCard,
    Amex,
    Discover

}
