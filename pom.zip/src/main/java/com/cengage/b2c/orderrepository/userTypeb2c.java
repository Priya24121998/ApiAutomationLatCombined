package com.cengage.b2c.orderrepository;

public enum userTypeb2c {
	existing,
	create
}
