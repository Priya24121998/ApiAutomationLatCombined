package com.cengage.b2c.orderrepository;

public enum rentalType {
	
	extension15,
	extension30,
	goodState,
	badState,
	buyout, 
	noRentalTypeSelected

}
