package com.cengage.b2c.orderrepository;

public enum PaymentType {
cc,
paypal
}
