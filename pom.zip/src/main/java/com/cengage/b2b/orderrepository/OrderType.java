package com.cengage.b2b.orderrepository;

public enum OrderType {
	singleOrder,
	fastPacedOrder

}
