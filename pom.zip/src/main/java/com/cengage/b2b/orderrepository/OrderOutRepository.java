package com.cengage.b2b.orderrepository;

import org.springframework.data.jpa.repository.JpaRepository;

public interface OrderOutRepository  extends JpaRepository<OrderOut, Integer>{

}
