package com.cengage.b2b.orderrepository;


public enum CreditCardType{
	Visa,
    MasterCard,
    Amex,
    Discover

}
